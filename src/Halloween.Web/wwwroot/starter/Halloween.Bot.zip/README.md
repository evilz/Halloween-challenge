﻿# Mon bot Halloween

Prerequis : SDK .NET 10 stable.

1. Dans ce dossier, lancer `dotnet run`.
2. Dans l'arÃ¨ne, ouvrir Mes bots et connecter http://localhost:5081.
3. Selectionner Mon premier bot et creer une nouvelle partie.
4. Modifier Program.cs pour changer la stratÃ©gie.

L'API expose POST /name et POST /move. Contracts.cs contient le format des observations.
Pour rendre le bot accessible depuis un serveur d'arene distant, heberger cette API sur une URL publique.
